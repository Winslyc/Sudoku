package com.example.sudoku.constants;

public enum Rows {
    TOP,
    MIDDLE,
    BOTTOM
}
