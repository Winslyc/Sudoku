package com.example.sudoku.constants;

public class Messages {
    public static final String GAME_COMPLETE = "Congratulation, you have won! New Game?";
    public static final String ERROR  = "An error has occurred.";

}
