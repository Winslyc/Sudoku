package com.example.sudoku.constants;

public enum GameState {
    COMPLETE,
    ACTIVE,
    NEW
}
